
<!doctype html>
<html class="no-js" >
	<head>
		<meta charset="utf-8">

		<title>Novas Empresas</title>
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<meta name="description" content="">
		<meta name="author" content="NovasEmpresas.com">

		<meta name="apple-mobile-web-app-capable" content="yes" />
		<meta name="mobile-web-app-capable" content="yes" />
		<meta name="apple-mobile-web-app-status-bar-style" content="black" />

		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link href="css/estilos.min.css" rel="stylesheet">

	</head>
	<body >
	
<div role="tabpanel">

						<!-- Nav tabs -->
						<ul class="nav nav-tabs" role="tablist">
							<li role="presentation" class="active"><a href="#registo" aria-controls="registo" role="tab" data-toggle="tab">Registe-se</a></li>
							<li role="presentation"><a href="#login" aria-controls="profile" role="tab" data-toggle="tab">Login</a></li>

						</ul>

						<!-- Tab panes -->
						<div class="tab-content">
							<div role="tabpanel" class="tab-pane active" id="registo">
								<form name="frmRegisto" >
									<div class="div_inputsRegisto">
										<h2>Registe-se aqui</h2>
										<div class="form-group">

											<input type="text" class="form-control" id="registoNome" placeholder="Nome" required>
										</div>
										<div class="form-group">

											<input type="email" class="form-control" id="registoEmail" placeholder="Email" required>
										</div>
										<div class="form-group">

											<input type="password" class="form-control" id="registoPassw" placeholder="Password" required>
										</div>

										<button type="submit" class="btn btn-success">Registar</button>
									</div>	
									<!--SÓ MOSTRA QUANDO O USER ESTÁ REGISTADO-->
									<div class="user_dados">
										<h3>Olá</h3>
										<p>{{MOSTRA O NOME}}</p>
									</div>
									<!--/SÓ MOSTRA QUANDO O USER ESTÁ REGISTADO-->
								</form>
							</div>
							<div role="tabpanel" class="tab-pane" id="login">
								<form name="frmLogin" >
									<div class="div_inputsRegisto">
										<h2>Login</h2>
										<div class="form-group">

											<input type="email" class="form-control" id="loginEmail" placeholder="Email" required>
										</div>
										<div class="form-group">

											<input type="password" class="form-control" id="loginPassw" placeholder="Password" required>
										</div>

										<button type="submit" class="btn btn-success">Login</button>
									</div>	
									<!--SÓ MOSTRA QUANDO O USER ESTÁ Logged in-->
									<div class="user_dados">
										<h3>Olá, {{NOME }}</h3>
										<p>Não é o {{NOME}}? Clique aqui</p><!-- Diminuir a font e colocar a vermelho -->
										<p><button type="submit" class="btn btn-danger">Sair</button></p>
									</div>
									<!--/SÓ MOSTRA QUANDO O USER ESTÁ Logged in-->
								</form>

							</div>

						</div>

					</div>
		
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</body>
</html>
